package com.example.mitny.termproject;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class listAdapter extends BaseAdapter{
    ArrayList<list_item> list_itemArrayList;
    TextView content1;
    TextView temp1;
    ImageView image1;
    ImageView temp2;

    public listAdapter(ArrayList<list_item> list_itemArrayList){
        this.list_itemArrayList = list_itemArrayList;
    }

    @Override
    public int getCount() {
        return this.list_itemArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return list_itemArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Context context = parent.getContext();
        if(convertView==null){
            convertView = LayoutInflater.from(context).inflate(R.layout.item, null);
            content1 = (TextView) convertView.findViewById(R.id.content1);
            temp1 = (TextView)convertView.findViewById(R.id.temp1);
            image1 = (ImageView)convertView.findViewById(R.id.image1);
            temp2 = (ImageView)convertView.findViewById(R.id.temp2);
        }

        content1.setText(list_itemArrayList.get(position).getContent1());
        temp1.setText(list_itemArrayList.get(position).getTemp1());
        image1.setImageResource(list_itemArrayList.get(position).getImage1());
        temp2.setImageResource(list_itemArrayList.get(position).getTemp2());
        return convertView;
    }
}