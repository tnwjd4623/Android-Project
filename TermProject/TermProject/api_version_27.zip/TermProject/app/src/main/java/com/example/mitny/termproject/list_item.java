package com.example.mitny.termproject;

public class list_item {
    private int image1;
    private String content1;
    private String temp1;
    private int temp2;

    public int getImage1() {
        return image1;
    }

    public String getContent1() {
        return content1;
    }

    public String getTemp1() {
        return temp1;
    }

    public void setImage1(int image1) {
        this.image1 = image1;
    }

    public void setContent1(String content1) {
        this.content1 = content1;
    }

    public void setTemp1(String temp1) {
        this.temp1 = temp1;
    }

    public void setTemp2(int temp2) {
        this.temp2 = temp2;
    }

    public int getTemp2() {
        return temp2;
    }

    public list_item(int image1, String content1, String temp1, int temp2) {
        this.image1 = image1;
        this.content1 = content1;
        this.temp1 = temp1;
        this.temp2 = temp2;
    }
}