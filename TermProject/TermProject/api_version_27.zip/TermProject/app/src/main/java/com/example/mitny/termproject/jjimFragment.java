package com.example.mitny.termproject;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class jjimFragment extends Fragment {
    listAdapter adapter;                             //리스트어뎁터
    ArrayList<list_item> list_itemArrayList;        //리스트 아이템들 추가하는 곳
    ListView listView;                               //리스트 출력하는 레이아웃

    public jjimFragment() {
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.jjim_fragment, container, false);
        listView = (ListView)view.findViewById(R.id.favoritelist);

        list_itemArrayList = new ArrayList<list_item>();

        /**
         * 리스트에 아이템 추가
         */
        list_itemArrayList.add(new list_item(R.drawable.img10, "content1", "19도", R.drawable.hot));
        list_itemArrayList.add(new list_item(R.drawable.img10, "content2", "20도", R.drawable.cold));
        list_itemArrayList.add(new list_item(R.drawable.img10, "content3", "10도", R.drawable.little_cold));
        list_itemArrayList.add(new list_item(R.drawable.img10, "content4", "25도", R.drawable.little_cold));
        list_itemArrayList.add(new list_item(R.drawable.img10, "content1", "19도", R.drawable.little_cold));
        list_itemArrayList.add(new list_item(R.drawable.img10, "content2", "20도", R.drawable.little_cold));
        list_itemArrayList.add(new list_item(R.drawable.img10, "content3", "10도", R.drawable.little_cold));
        list_itemArrayList.add(new list_item(R.drawable.img10, "content4", "25도", R.drawable.little_cold));

        adapter = new listAdapter(list_itemArrayList);
        listView.setAdapter(adapter);


        return view;
    }
}